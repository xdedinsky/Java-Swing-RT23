package sk.stuba.fei.uim.oop.controls;

import sk.stuba.fei.uim.oop.window.MyBoard;

import lombok.Getter;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;

public class Logic extends UniversalAdapter{
    @Getter
    private MyBoard myBoard;

    public Logic() {
        this.myBoard = new MyBoard();
        this.myBoard.addMouseMotionListener(this);
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        this.myBoard.addPoint(e.getX(), e.getY());
        this.myBoard.removePoints();
        this.myBoard.revalidate();
        this.myBoard.repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() instanceof JComboBox) {
            this.myBoard.setItem((String) (((JComboBox) e.getSource()).getSelectedItem()));
            this.myBoard.revalidate();
            this.myBoard.repaint();
        }
    }
}
