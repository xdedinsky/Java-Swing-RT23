package sk.stuba.fei.uim.oop.controls;

import sk.stuba.fei.uim.oop.window.MyBoard;
import sk.stuba.fei.uim.oop.window.MySideMenu;

import javax.swing.*;
import javax.swing.event.ChangeEvent;

public class SliderLogic extends UniversalAdapter {
    private MyBoard myBoard;
    private MySideMenu mySideMenu;

    public SliderLogic(MyBoard board, MySideMenu sideMenu){
        this.myBoard = board;
        this.mySideMenu = sideMenu;
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (e.getSource().equals(mySideMenu.getLengthSlider())){
            myBoard.setLength(((JSlider) e.getSource()).getValue());
        }
        if (e.getSource().equals(mySideMenu.getSpacingSlider())){
            myBoard.setSpacing(((JSlider) e.getSource()).getValue());
        }
        if (e.getSource().equals(mySideMenu.getRadiusSlider())){
            myBoard.setRadius(((JSlider) e.getSource()).getValue());
        }
    }
}
