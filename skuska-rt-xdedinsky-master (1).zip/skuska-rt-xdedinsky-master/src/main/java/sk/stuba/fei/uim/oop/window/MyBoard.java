package sk.stuba.fei.uim.oop.window;

import lombok.Setter;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static sk.stuba.fei.uim.oop.window.MyWindow.*;

public class MyBoard extends JPanel {
    @Setter
    private String item;
    @Setter
    private List<Point> points;
    @Setter
    private int length;
    @Setter
    private int radius;
    @Setter
    private int spacing;
    public MyBoard() {
        this.item = CIRCLE_ITEM;
        this.points = new ArrayList<>();
        this.length = 50;
        this.spacing = 5;
        this.radius = 5;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);

        if (points.size()>=1) {
            int number = 0;
            for (int i = 0; i < points.size()-1; i++) {
                int currentX = this.points.get(i).getX();
                int currentY = this.points.get(i).getY();
                int nextX = this.points.get(i+1).getX();
                int nextY = this.points.get(i+1).getY();
                g.drawLine(currentX, currentY, nextX, nextY);
                if(i == points.size()-1 || i % spacing == 0) {
                    number += 1;
                    g.setColor(Color.getHSBColor((float) number / (float) length, 0.85f, 1.0f));
                    if (this.item.equals(CIRCLE_ITEM)) {
                        g.fillOval(currentX-radius, currentY-radius, 2*radius, 2*radius);
                    }
                    if (this.item.equals(SQUARE_ITEM)) {
                        g.fillRect(currentX-radius, currentY-radius, 2*radius, 2*radius);
                    }
                    if (this.item.equals(WATCHES_ITEM)) {
                        g.fillPolygon(new int[] {currentX, currentX-radius, currentX+radius}, new int[] {currentY, currentY+radius, currentY+radius}, 3);
                        g.fillPolygon(new int[] {currentX, currentX-radius, currentX+radius}, new int[] {currentY, currentY-radius, currentY-radius}, 3);
                    }
                }
            }
        }
    }

    public void addPoint(int x, int y) {
        this.points.add(new Point(x,y));
    }

    public void removePoints() {
        while(this.points.size() > length) {
            this.points.remove(0);
        }
    }
}
