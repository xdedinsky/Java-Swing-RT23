package sk.stuba.fei.uim.oop.window;

import sk.stuba.fei.uim.oop.controls.Logic;

import javax.swing.*;
import java.awt.*;

public class MyWindow extends JFrame {
    public static final String CIRCLE_ITEM = "Circle";
    public static final String SQUARE_ITEM = "Square";
    public static final String WATCHES_ITEM = "Watches";
    public MyWindow() {
        super("OOP-RT23");
        this.setSize(1000,700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.setResizable(false);
        this.setFocusable(true);

        Logic logic = new Logic();
        this.addKeyListener(logic);
        new MySideMenu(this,logic);

        this.revalidate();
        this.repaint();
        this.setVisible(true);
    }
}
