package sk.stuba.fei.uim.oop.window;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.controls.Logic;
import sk.stuba.fei.uim.oop.controls.SliderLogic;

import javax.swing.*;
import java.awt.*;

import static sk.stuba.fei.uim.oop.window.MyWindow.*;

public class MySideMenu {
    @Getter @Setter
    private JSlider lengthSlider;
    @Getter@Setter
    private JSlider radiusSlider;
    @Getter@Setter
    private JSlider spacingSlider;
    public MySideMenu(JFrame frame, Logic logic) {
        JPanel sideMenu = new JPanel();
        sideMenu.setLayout(new BorderLayout());

        SliderLogic sliderLogicListener = new SliderLogic(logic.getMyBoard(),this);

        lengthSlider = new JSlider(JSlider.VERTICAL, 20,200,50);
        lengthSlider.setMajorTickSpacing(10);
        lengthSlider.setPaintTicks(true);
        lengthSlider.setPaintLabels(true);
        lengthSlider.setSnapToTicks(true);
        lengthSlider.setFocusable(false);
        lengthSlider.addChangeListener(sliderLogicListener);

        radiusSlider = new JSlider(JSlider.VERTICAL, 1,20,5);
        radiusSlider.setMajorTickSpacing(1);
        radiusSlider.setPaintTicks(true);
        radiusSlider.setPaintLabels(true);
        radiusSlider.setSnapToTicks(true);
        radiusSlider.setFocusable(false);
        radiusSlider.addChangeListener(sliderLogicListener);

        spacingSlider = new JSlider(JSlider.VERTICAL, 1,20,5);
        spacingSlider.setMajorTickSpacing(1);
        spacingSlider.setPaintTicks(true);
        spacingSlider.setPaintLabels(true);
        spacingSlider.setSnapToTicks(true);
        spacingSlider.setFocusable(false);
        spacingSlider.addChangeListener(sliderLogicListener);

        String[] things = {CIRCLE_ITEM, SQUARE_ITEM, WATCHES_ITEM};
        JComboBox itemsBox = new JComboBox(things);
        itemsBox.setSelectedIndex(0);
        itemsBox.setFocusable(false);
        itemsBox.addActionListener(logic);

        JPanel sideMenuLeft = new JPanel();
        sideMenuLeft.setLayout(new GridLayout(1,3));

        JLabel lengthLabel = new JLabel();
        lengthLabel.setText("Length");
        sideMenuLeft.add(lengthLabel);
        JLabel radiusLabel = new JLabel();
        radiusLabel.setText("Radius");
        sideMenuLeft.add(radiusLabel);
        JLabel spacingLabel = new JLabel();
        spacingLabel.setText("Spacing");
        sideMenuLeft.add(spacingLabel);

        JPanel sideMenuMid = new JPanel();
        sideMenuMid.setLayout(new GridLayout(1,3));
        sideMenuMid.add(lengthSlider);
        sideMenuMid.add(radiusSlider);
        sideMenuMid.add(spacingSlider);

        sideMenuLeft.setBackground(Color.CYAN);

        JPanel sideMenuBottom = new JPanel();
        sideMenuBottom.setLayout(new BorderLayout());
        sideMenuBottom.add(itemsBox);
        sideMenuBottom.setBackground(Color.CYAN);

        sideMenu.add(sideMenuLeft,BorderLayout.NORTH);
        sideMenu.add(sideMenuMid);
        sideMenu.add(sideMenuBottom, BorderLayout.PAGE_END);

        frame.add(sideMenu, BorderLayout.WEST);
        frame.add(logic.getMyBoard());
    }
}
