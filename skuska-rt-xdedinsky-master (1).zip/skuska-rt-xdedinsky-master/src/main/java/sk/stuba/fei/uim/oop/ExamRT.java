package sk.stuba.fei.uim.oop;

import sk.stuba.fei.uim.oop.window.MyWindow;

public class ExamRT {
    public static void main(String[] args) {
        new MyWindow();
    }
}
